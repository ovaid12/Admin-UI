import "./styles.css";
import Fetch from "./components/fetch";
export default function App() {
  return (
    <div className="App">
      <Fetch />
    </div>
  );
}
